H5P Collage
==========

Put together images in a beautiful collage for your web site og blog.

## License

*H5P Collage* is [MIT licensed](LICENSE.md)
