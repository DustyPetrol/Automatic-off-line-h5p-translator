import eslintConfigSnordianH5P from 'eslint-config-snordian-h5p';

export default [
  eslintConfigSnordianH5P.configs['flat/recommended']
];
